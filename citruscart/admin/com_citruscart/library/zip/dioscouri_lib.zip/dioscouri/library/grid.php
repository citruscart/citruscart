<?php

/*------------------------------------------------------------------------
# com_example
# ------------------------------------------------------------------------
# author   Weblogicx Team  - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2014 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://example.org
# Technical Support:  Forum - http://example.org/forum/index.html
-------------------------------------------------------------------------*/
/** ensure this file is being included by a parent file */
defined('_JEXEC') or die('Restricted access');


if (version_compare(JVERSION, '3.0', 'ge'))
{
     require_once( JPATH_SITE . '/libraries/dioscouri/library/grid30.php' );

}
else if (version_compare(JVERSION, '2.5', 'ge'))
{
    require_once( JPATH_SITE . '/libraries/dioscouri/library/grid16.php' );

}
else
{
    require_once( JPATH_SITE . '/libraries/dioscouri/library/grid15.php' );

}